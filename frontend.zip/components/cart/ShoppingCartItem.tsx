
import { CartItem } from "@/src/schemas";
import { formatCurrency } from "@/src/utils";
import Image from "next/image";
import { useStore } from "@/src/store";

export default function ShoppingCartItem({ item }: { item: CartItem }) {
    const updateQuantity = useStore(state => state.updateQuantity)
    const removeFromCart = useStore(state => state.removeFromCart)
    return (
        <li className="flex items-center space-x-6 py-6 relative">
            <div className='h-24 w-24'>
                <Image
                    src={`${process.env.NEXT_PUBLIC_API_URL}/img/${item.image}`}
                    alt={`Imagen del producto ${item.name}`}
                    width={100}
                    height={100}
                    priority
                />
            </div>
            {/*Informacion del producto en el carrio de compras*/}
            <div className="flex-auto space-y-2">
                {/* nombre del producto*/}
                <h3 className="text-gray-900"> {item.name}</h3>
                {/* presentacion del producto*/}
                <h3 className="text-gray-400"> {item.presentation.description}</h3>
                {/* precio del producto*/}
                <p> {formatCurrency(item.priceFinal)}</p>
                {/* cantidad del producto*/}
                <select
                    className="w-32 text-center p-2 rounded-lg bg-gray-100"
                    value={item.quantity}
                    onChange={(e) => updateQuantity(item.productId, +e.target.value)}
                >
                    {/*Genera un rango de numeros desde 1 hasta el inventario del producto*/}
                    {Array.from(
                        { length: item.inventory > 0 ? item.inventory : 10 },
                        (_, index) => index + 1
                    ).map(num => (
                        <option key={num} value={num}>
                            {num}
                        </option>
                    ))}
                </select>
            </div>
            {/*Boton para eliminar el producto del carrito*/}
            <div className='absolute top-10 -right-0'>
                <button
                    type="button"
                    onClick={() => removeFromCart(item.productId)}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-8 h-8 text-red-500">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </button>
            </div>
        </li>
    )
}